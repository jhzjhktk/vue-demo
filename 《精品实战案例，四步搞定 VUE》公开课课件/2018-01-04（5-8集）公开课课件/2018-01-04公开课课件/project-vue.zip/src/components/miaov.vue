<template>
  <div>
    <h2>统计总数：{{$store.getters.totals}}</h2>
  </div>
</template>
<script>
  export default {
    
  }
</script>
<style>
@import url();
</style>

